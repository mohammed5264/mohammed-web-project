const title = document.querySelector("h1");
title.addEventListener("click", () => {
  title.style.color = "#e67e22";
  console.log("Thank you for exploring Glasgow!");
});
